document.addEventListener("DOMContentLoaded", function () {
    const imageUrlInput = document.getElementById("imageUrl");
    const képszélInput = document.getElementById("képszél");
    const képvasInput = document.getElementById("képvas");
    const képszínInput = document.getElementById("képszín");
    const image = document.getElementById("image");
    const sötétmódButton = document.getElementById("sötétmód");

    imageUrlInput.addEventListener("input", updateImage);
    képszélInput.addEventListener("input", updateImage);
    képvasInput.addEventListener("input", updateImage);
    képszínInput.addEventListener("input", updateImage);

    function updateImage() {
        const imageUrl = imageUrlInput.value;
        const képszél = képszélInput.value + "px";
        const képvas = képvasInput.value + "px";
        const képszín = képszínInput.value;

        image.src = imageUrl;
        image.style.width = képszél;
        image.style.border = `${képvas} solid ${képszín}`;
    }

    sötétmódButton.addEventListener("click", function () {
        document.body.classList.toggle("dark-mode");
    });
});
